﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using ManagementPortal.Enums;
using System.Web.Mvc;

namespace ManagementPortal.Models
{
    public class Job
    {
        [Key]
        [Display(Name = "User Id")]
        public string Id { get; set; }
        [Display(Name = "Email")]
        public string Email { get; set; }
        [Display(Name = "PasswordHash")]
        public string PasswordHash { get; set; }
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        [Display(Name = "Work Type")]
        public WorkType WorkType { get; set; }
        [Display(Name = "Phone Number")]
        public string PhoneNumber { get; set; }
        [Display(Name = "User Role")]
        public string UserRole { get; set; }
        [Display(Name = "State")]
        public string State { get; set; }
        public IEnumerable<SelectListItem> States { get; set; }
        [Display(Name = "County")]
        public string County { get; set; }
        [Display(Name = "Zip Code")]
        public string ZipCode { get; set; }
        [Display(Name = "Suspended")]
        public bool Suspended { get; set; }
    }
}