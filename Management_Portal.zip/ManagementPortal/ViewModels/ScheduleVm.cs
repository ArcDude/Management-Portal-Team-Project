﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ManagementPortal.ViewModels
{
    public class ScheduleVm
    {
    }
}